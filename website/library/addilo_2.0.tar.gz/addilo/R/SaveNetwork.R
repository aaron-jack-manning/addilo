SaveNetwork <-
function(network, file.path = "neuralnetwork.Rds")
{
	saveRDS(network, file.path)
}
