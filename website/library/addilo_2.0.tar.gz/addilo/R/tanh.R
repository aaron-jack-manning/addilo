tanh <-
function(x) { return((2 / (1 + exp(-2 * x))) - 1) }
