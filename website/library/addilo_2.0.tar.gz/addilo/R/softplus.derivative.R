softplus.derivative <-
function(x) { return(1 / (1 + exp(-x))) }
