arctan.derivative <-
function(x) { return(1 / (x^2 + 1)) }
