arctan <-
function(x) { return(atan(x)) }
