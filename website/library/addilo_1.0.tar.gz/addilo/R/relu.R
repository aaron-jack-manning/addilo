relu <-
function(x) { return(ifelse(x > 0, x, 0)) }
