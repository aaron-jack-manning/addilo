RecallNetwork <-
function(file.path = "neuralnetwork.Rds")
{
	return(readRDS(file.path))
}
