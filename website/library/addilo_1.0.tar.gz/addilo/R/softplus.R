softplus <-
function(x) { return(log(1 + exp(x))) }
