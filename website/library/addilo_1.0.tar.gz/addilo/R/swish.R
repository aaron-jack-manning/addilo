swish <-
function(x) { return(x / (1 + exp(-x))) }
