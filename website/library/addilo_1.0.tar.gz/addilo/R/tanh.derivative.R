tanh.derivative <-
function(x) { return((4 * exp(-2 * x)) / ((exp(-2 * x) + 1)^2)) }
